#include "comum.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void editor(char *carros_binario) {
  int contagem; //Variável para o scanf
  Node *lista = NULL;
  int opcao;
  ler_dados(&lista, carros_binario);
  //Lista de opções para o usuário
  do {
    printf("Escolha uma opção:\n");
    printf("1 - Inserir dados\n");
    printf("2 - Remover dados\n");
    printf("3 - Exibir um dado\n");
    printf("4 - Exibir lista completa\n");
    printf("5 - Sair\n");
    contagem = scanf("%d", &opcao);
    //Se ele digita uma opção inválida, volta para o menu
    while (opcao < 1 || opcao > 5) {
      printf("Opção inválida. Digite novamente: ");
      contagem = scanf("%d", &opcao);
    }
    //Chama as funções necessárias para o programa editor
    if (opcao == 1) {
      inserir_dados(&lista, carros_binario);
    } else if (opcao == 2) {
      remover_dados(&lista, carros_binario);
    } else if (opcao == 3) {
      buscar_dados(lista);
    } else if (opcao == 4) {
      exibir_lista(lista);
    } else if (opcao == 5) {
      liberar_lista(lista);
      printf("Saindo...\n");
    }
    printf("\n");
  } while (opcao != 5);
}