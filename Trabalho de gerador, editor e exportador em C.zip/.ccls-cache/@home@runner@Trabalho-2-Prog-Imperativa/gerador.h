#ifndef GERADOR_H
#define GERADOR_H

void gerador(char *carros_entrada, char *carros_binario);

#endif