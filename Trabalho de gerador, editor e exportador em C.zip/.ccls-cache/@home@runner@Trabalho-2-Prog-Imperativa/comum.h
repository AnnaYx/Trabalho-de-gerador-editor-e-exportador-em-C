#ifndef COMUM_H
#define COMUM_H
#define MAX_SIZE 1000

// Declaração de estrutura compartilhada
// Definir estrutura para o arquivo
typedef struct Carro{
    int id;
    char nome[MAX_SIZE];
    char marca[MAX_SIZE];
    int ano;
} Carro;

// Representar o nó da lista
typedef struct Node {
  Carro carro;
  struct Node *proximo;
} Node;

// Declaração de função compartilhada
void ler_arquivo(Node **lista, char *carros_entrada);
void gravar_arquivo(Node *lista, char *carros_binario);
void ler_dados(Node **lista, char *carros_binario);
void liberar_lista(Node *lista);
void trocar_nos(Node* a, Node* b);
void ordenar_lista(Node* lista);
void exibir_lista(Node *lista);
int verifica_id_existente(Node *lista, int id);
void inserir_dados(Node **lista, char *carros_binario);
void remover_dados(Node **lista, char *carros_binario);
void buscar_dados(Node *lista);

#endif

