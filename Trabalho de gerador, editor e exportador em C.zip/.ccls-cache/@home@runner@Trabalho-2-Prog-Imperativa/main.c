#include "comum.h"
#include "editor.h"
#include "exportador.h"
#include "gerador.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
  if (argc < 4) {
    printf("Envie no mínimo 3 argumentos\n"); //Erro se não declarar os argumentos necessários
    return -1;
  }
  // Nome das variáveis para armazenar os nomes dos arquivos
  char *carros_entrada = argv[1];
  char *carros_binario = argv[2];
  char *carros_saida = argv[3];
  // Chamar as funções do gerador, editor e exportador para serem executadas
  gerador(carros_entrada, carros_binario);
  editor(carros_binario);
  exportador(carros_binario, carros_saida);
}
