#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "comum.h"

//Chama as funções necessárias para o programa gerador
void gerador(char *carros_entrada, char *carros_binario) {
  Node *lista = NULL;
  ler_arquivo(&lista, carros_entrada);
  ordenar_lista(lista);
  gravar_arquivo(lista, carros_binario);
  liberar_lista(lista);
}


