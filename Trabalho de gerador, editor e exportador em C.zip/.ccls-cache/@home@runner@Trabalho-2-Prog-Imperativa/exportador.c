#include "comum.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void exportador(char *carros_binario, char *carros_saida) {

  //Abre os arquivos que ele vai ler e escrever
  FILE *binario = fopen(carros_binario, "rb");
  FILE *arquivo = fopen(carros_saida, "w");

  if (binario == NULL || arquivo == NULL) {
    perror("Erro ao abrir os arquivos");
  }

  Carro carro;

  // Lê dados do arquivo binário e escreve no arquivo de texto
  while (fread(&carro, sizeof(Carro), 1, binario) == 1) {
    fprintf(arquivo, "%d %s %s %d\n", carro.id, carro.nome, carro.marca,
            carro.ano);
  }
  fclose(binario);
  fclose(arquivo);
  printf("Arquivo de texto gerado com sucesso.\n");
}
