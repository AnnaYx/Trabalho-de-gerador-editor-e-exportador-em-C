#ifndef EXPORTADOR_H
#define EXPORTADOR_H

void exportador(char *carros_binario, char *carros_saida);

#endif