#include "comum.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Função para inserir um elemento no final da lista
Node *inserir_elemento(Node *lista, Carro carro) {
  Node *novo_no = (Node *)malloc(sizeof(Node));
  novo_no->carro = carro;
  novo_no->proximo = NULL;

  if (lista == NULL) {
    // Se a lista estiver vazia, o novo nó será o primeiro da lista
    return novo_no;
  }

  Node *atual = lista;
  while (atual->proximo != NULL) {
    // Avança até o final da lista
    atual = atual->proximo;
  }

  // Adiciona o novo nó no final da lista
  atual->proximo = novo_no;
  return lista;
}

// Ler arquivo txt e armazenar em lista encadeada
void ler_arquivo(Node **lista, char *carros_entrada) {
  FILE *arquivo;
  Carro carro;
  char linha[MAX_SIZE];
  char *token;

  arquivo = fopen(carros_entrada, "r");
  if (arquivo == NULL) {
    printf("Erro ao abrir o arquivo.\n"); // Mensagem de erro se o arquivo está
                                          // vazio
    exit(1);
  }

  while (fgets(linha, MAX_SIZE, arquivo) != NULL) {
    token = strtok(linha, " "); // Função strtok para dividir a linha em
                                // "tokens" usando o espaço como delimitador
    carro.id = atoi(token); // Converte o token para um número inteiro usando a
                            // função atoi e atribui o valor convertido à
                            // propriedade id da estrutura carro

    token = strtok(NULL, " "); // NULL como primeiro argumento para continuar a
                               // partir do ponto onde a última chamada parou.
    strcpy(carro.nome, token); // Copia o token para a propriedade nome da
                               // estrutura carro usando a função strcpy

    token = strtok(NULL, " ");
    strcpy(carro.marca, token);

    token = strtok(NULL, " ");
    carro.ano = atoi(token);

    // Adicionar o carro à lista
    *lista = inserir_elemento(*lista, carro);
  }
  printf("Lista criada\n");
  fclose(arquivo);
}

// Função de trocar nós para ordenar a lista na próxima função
void trocar_nos(Node *a, Node *b) {
  Carro temp = a->carro;
  a->carro = b->carro;
  b->carro = temp;
}

// Coloca lista em ordem crescente pelo id
void ordenar_lista(Node *lista) {
  int trocado;
  Node *no_atual;
  Node *no_seguinte = NULL;

  // Verificar se a lista está vazia
  if (lista == NULL)
    return;

  // Ordena os dados utilizando a função de trocar nós
  do {
    trocado = 0;
    no_atual = lista;

    while (no_atual->proximo != no_seguinte) {
      if (no_atual->carro.id > no_atual->proximo->carro.id) {
        trocar_nos(no_atual, no_atual->proximo);
        trocado = 1;
      }
      no_atual = no_atual->proximo;
    }
    no_seguinte = no_atual;
  } while (trocado);
}

// Liberar lista encadeada
void liberar_lista(Node *lista) {
  Node *atual = lista;
  while (atual != NULL) {
    Node *proximo = atual->proximo;
    free(atual);
    atual = proximo;
  }
  lista = NULL;
  printf("Lista encadeada liberada.\n");
}

// Grava esses dados em um arquivo binário
void gravar_arquivo(Node *lista, char *carros_binario) {
  FILE *arquivo;
  arquivo = fopen(carros_binario, "wb");
  if (arquivo == NULL) {
    printf("Erro ao abrir o arquivo.\n");
    exit(1);
  }
  while (lista != NULL) {
    fwrite(&lista->carro, sizeof(Carro), 1, arquivo);
    lista = lista->proximo;
  }
  fclose(arquivo);
}

// Lê dados do arquivo binário carros.bin
void ler_dados(Node **lista, char *carros_binario) {
  FILE *arquivo = fopen(carros_binario, "rb");
  if (arquivo == NULL) {
    printf(
        "Erro ao abrir arquivo.\n"); // Mensagem de erro se o arquivo está vazio
    return;
  }
  Carro carro;
  while (fread(&carro, sizeof(Carro), 1, arquivo) == 1) {
    Node *novo_no = (Node *)malloc(sizeof(Node));
    novo_no->carro = carro;
    novo_no->proximo = NULL;
    if (*lista == NULL) {
      *lista = novo_no;
    } else {
      Node *atual = *lista;
      while (atual->proximo != NULL) {
        atual = atual->proximo;
      }
      atual->proximo = novo_no;
    }
  }
  fclose(arquivo);
}

// Exibir lista completa
void exibir_lista(Node *lista) {
  Node *atual = lista;
  while (atual != NULL) {
    printf("Id: %d\n", atual->carro.id);
    printf("Nome: %s\n", atual->carro.nome);
    printf("Marca: %s\n", atual->carro.marca);
    printf("Ano: %d\n", atual->carro.ano);
    printf("\n");
    atual = atual->proximo;
  }
  printf("\n");
}

// Buscar id pra ver se ele já existe
int verifica_id_existente(Node *atual, int id) {
    if (atual == NULL) {
        return 0; // ID não existe
    }

    if (atual->carro.id == id) {
        printf("ID já existe. Digite um novo ID. ");
        return 1; // ID já existe
    }

    return verifica_id_existente(atual->proximo, id);
}

// Opção de inserir novos dados e gravar em arquivo binário
void inserir_dados(Node **lista, char *carros_binario) {
  int contagem; // Variável para o scanf
  Carro carro;
  do {
    printf("Digite o ID: ");
    contagem = scanf("%d", &carro.id);
  } while (verifica_id_existente(*lista, carro.id));
  printf("Digite o nome do carro: ");
  contagem = scanf("%s", carro.nome);
  printf("Digite a marca do carro: ");
  contagem = scanf("%s", carro.marca);
  printf("Digite o ano do carro: ");
  contagem = scanf("%d", &carro.ano);
  Node *novo_no = (Node *)malloc(sizeof(Node));
  novo_no->carro = carro;
  novo_no->proximo = NULL;
  if (*lista == NULL) {
    *lista = novo_no;
  } else {
    Node *atual = *lista;
    while (atual->proximo != NULL) {
      atual = atual->proximo;
    }
    atual->proximo = novo_no;
  }
  ordenar_lista(*lista);
  gravar_arquivo(*lista, carros_binario);
}

// Opção de remover dados pelo id e gravar no arquivo binário
void remover_dados(Node **lista, char *carros_binario) {
  int id;
  int contagem;
  printf("Digite o ID do carro a ser removido: ");
  contagem = scanf("%d", &id);
  Node *atual = *lista;
  Node *anterior = NULL;
  while (atual != NULL && atual->carro.id != id) {
    anterior = atual;
    atual = atual->proximo;
  }
  if (atual == NULL) {
    printf("Carro com ID %d não encontrado.\n", id);
    return;
  }
  if (anterior == NULL) {
    *lista = atual->proximo;
  } else {
    anterior->proximo = atual->proximo;
  }
  FILE *arquivo = fopen(carros_binario, "wb");
  if (arquivo == NULL) {
    printf("Erro ao abrir arquivo.\n"); // Mensagem de erro se o arquivo está vazio
    return;
  }
  Node *atual2 = *lista;
  while (atual2 != NULL) {
    fwrite(&atual2->carro, sizeof(Carro), 1, arquivo);
    atual2 = atual2->proximo;
  }
  fclose(arquivo);
  printf("Carro com ID %d removido com sucesso.\n", id);
  free(atual);
}

// Exibir o carro buscado pelo id
void buscar_dados(Node *lista) {
  int contagem;
  int id;
  printf("Digite o ID do carro a ser buscado: ");
  contagem = scanf("%d", &id);
  Node *atual = lista;
  while (atual != NULL) {
    if (atual->carro.id == id) {
      printf("ID: %d\n", atual->carro.id);
      printf("Nome: %s\n", atual->carro.nome);
      printf("Marca: %s\n", atual->carro.marca);
      printf("Ano: %d\n", atual->carro.ano);
      return;
    }
    atual = atual->proximo;
  }
  printf("Carro não encontrado.\n");
}