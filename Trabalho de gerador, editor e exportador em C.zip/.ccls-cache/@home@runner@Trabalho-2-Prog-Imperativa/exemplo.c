
//A função realloc é uma função em C (e em algumas outras linguagens de programação) que é usada para reatribuir o tamanho da memória alocada dinamicamente. Em outras palavras, ela é usada para alterar o tamanho de um bloco de memória que foi alocado anteriormente usando funções como malloc, calloc ou realloc em um espaço de memória diferente

//A função realloc tenta alterar o tamanho da memória apontada por ptr para o novo tamanho especificado por size. Se a operação for bem-sucedida, ela retorna um ponteiro para a nova área de memória alocada. Se não for possível realizar a realocação, ela retorna NULL, e a memória original permanece inalterada.

//Este é um exemplo básico, e em programas mais complexos, você deve garantir que lida adequadamente com casos em que a realocação pode falhar (por exemplo, devido à falta de memória). Além disso, é sempre uma boa prática verificar se o ponteiro retornado por realloc é diferente de NULL antes de usar o novo bloco de memória alocado.


/*

#include <stdio.h>
#include <stdlib.h>

int main3() {
    // Alocar um bloco inicial de memória
    int *p = (int *)malloc(3 * sizeof(int));

    if (p == NULL) {
        printf("Erro na alocação de memória\n");
        return 1;
    }

    // Atribuir valores ao bloco de memória
    p[0] = 1;
    p[1] = 2;
    p[2] = 3;

    // Imprimir os valores originais
    printf("Valores originais:\n");
    for (int i = 0; i < 3; i++) {
        printf("%d ", p[i]);
    }
    printf("\n");

    // Realocar para um bloco de memória maior
    p = (int *)realloc(p, 5 * sizeof(int));

    if (p == NULL) {
        printf("Erro na realocação de memória\n");
        return 1;
    }

    // Atribuir valores adicionais ao bloco de memória realocado
    p[3] = 4;
    p[4] = 5;

    // Imprimir os valores após a realocação
    printf("Valores após realocação:\n");
    for (int i = 0; i < 5; i++) {
        printf("%d ", p[i]);
    }
    printf("\n");

    // Liberar a memória alocada
    free(p);

    return 0;
}




//Para organizar números em ordem crescente em C, você pode usar uma variedade de algoritmos de ordenação, sendo o algoritmo de ordenação rápida (qsort) um exemplo comum. Aqui está um exemplo simples de como você pode usar qsort para organizar um array de números em ordem crescente:

#include <stdio.h>
#include <stdlib.h>

// Função de comparação para qsort
int comparacao(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

int main4() {
    int numeros[] = {5, 2, 9, 1, 5, 6};

    // Tamanho do array
    int tamanho = sizeof(numeros) / sizeof(numeros[0]);

    // Usar qsort para ordenar o array
    qsort(numeros, tamanho, sizeof(numeros[0]), comparacao);

    // Imprimir os números ordenados
    printf("Números em ordem crescente:\n");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", numeros[i]);
    }
    printf("\n");

    return 0;
}



//Para organizar números em ordem crescente em uma lista encadeada em C, você pode usar um algoritmo de ordenação adequado para listas encadeadas. Um algoritmo comum é o algoritmo de ordenação por inserção. Aqui está um exemplo simples de como você pode implementar isso:

c
Copy code
#include <stdio.h>
#include <stdlib.h>

// Definição da estrutura do nó da lista encadeada
struct Node {
    int data;
    struct Node* next;
};

// Função para inserir um novo nó na lista encadeada ordenadamente
void insertSorted(struct Node** head, int newData) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = newData;
    newNode->next = NULL;

    // Caso a lista esteja vazia ou o novo nó deve ser inserido no início
    if (*head == NULL || newData < (*head)->data) {
        newNode->next = *head;
        *head = newNode;
    } else {
        // Encontrar o nó anterior onde o novo nó deve ser inserido
        struct Node* current = *head;
        while (current->next != NULL && current->next->data < newData) {
            current = current->next;
        }

        // Inserir o novo nó após o nó anterior
        newNode->next = current->next;
        current->next = newNode;
    }
}

// Função para imprimir os elementos da lista encadeada
void printList(struct Node* head) {
    struct Node* current = head;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

// Função para liberar a memória alocada para a lista encadeada
void freeList(struct Node** head) {
    struct Node* current = *head;
    struct Node* next;

    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }

    *head = NULL;
}

int main5() {
    // Inicializar a lista encadeada
    struct Node* head = NULL;

    // Inserir elementos desordenados
    insertSorted(&head, 5);
    insertSorted(&head, 2);
    insertSorted(&head, 9);
    insertSorted(&head, 1);
    insertSorted(&head, 5);
    insertSorted(&head, 6);

    // Imprimir a lista ordenada
    printf("Lista ordenada: ");
    printList(head);

    // Liberar a memória alocada
    freeList(&head);

    return 0;
} */
//Neste exemplo, a função insertSorted é responsável por inserir um novo nó ordenadamente na lista encadeada. A função printList é usada para imprimir os elementos da lista. Lembre-se de liberar a memória alocada ao final do programa usando a função freeList. Este é apenas um exemplo e existem outras maneiras de ordenar listas encadeadas, dependendo dos requisitos específicos do seu projeto.





