#ifndef EDITOR_H
#define EDITOR_H

void editor(char *carros_binario);

#endif